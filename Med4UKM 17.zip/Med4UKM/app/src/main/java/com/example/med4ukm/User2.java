package com.example.med4ukm;

public class User2 {

    String name, date, contact, nric, type;

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getContact() {
        return contact;
    }

    public String getNric() {
        return nric;
    }

    public String getType() {
        return type;
    }
}
