package com.example.med4ukm;

public class ModelClass {

    String title;
    String description;
    boolean isVisible;

    public ModelClass(String title, String description, boolean isVisible) {
        this.title = title;
        this.description=description;
        this.isVisible = isVisible;
    }
}
