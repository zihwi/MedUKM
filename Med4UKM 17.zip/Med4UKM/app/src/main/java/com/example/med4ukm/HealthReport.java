package com.example.med4ukm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HealthReport extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_report);
    }
}